﻿using CodeFirstApproachImpl.Models;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;

namespace CodeFirstApproachImpl.Data
{
    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        {

        }

        public DbSet<Emp> emps { get; set; }

        public DbSet<Employees> employee { get; set; }

        public DbSet<Managers> manager { get; set; }

        public DbSet<Product> products { get; set; }

    }
}

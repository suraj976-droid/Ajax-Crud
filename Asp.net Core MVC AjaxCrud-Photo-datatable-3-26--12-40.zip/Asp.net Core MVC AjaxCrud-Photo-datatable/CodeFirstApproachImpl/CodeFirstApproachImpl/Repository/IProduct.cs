﻿using CodeFirstApproachImpl.Models;

namespace CodeFirstApproachImpl.Repository
{
    public interface IProduct 
    {
        void AddProduct(Product p);
        
        List<Product> FetchProduct();

        void DeleteProduct(int id);
        List<Product> Searchproduct(string str);

    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirstApproachImpl.Models
{
    public class Employees
    {
        [Key]
        public int eid { get; set; }
        public string ename { get; set; }

        public double esalary { get; set; }

        [ForeignKey("mng")]
        public int Mid { get; set; }
        public Managers mng { get; set; }

    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproachImpl.Models
{
    public class Managers
    {
        [Key]
        public int Mid { get; set; }

        public string Mname { get; set; }

        public string Dname { get; set; }
    }
}
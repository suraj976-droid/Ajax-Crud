﻿using CodeFirstApproachImpl.Data;
using CodeFirstApproachImpl.Models;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace CodeFirstApproachImpl.Controllers
{
    public class AjaxController : Controller
    {
      
        private readonly ApplicationDbContext db;
        public AjaxController(ApplicationDbContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddProduct(Product p)
        {
            db.products.Add(p);
            db.SaveChanges();
            return Json("");
        }

        public IActionResult FetchProduct()
        {
         var data = db.products.ToList();
            return Json(data);
        }

     public IActionResult DelProd(int pid)
        {
            var data = db.products.Find(pid);
            db.products.Remove(data);
            db.SaveChanges();
            return Json("");
        }

       public IActionResult SearchProducts(string mydata)
        {
              var data = db.products.Where(x=>  x.Pname.Contains(mydata) || x.Pcat.Contains(mydata) || x.Price.ToString().Contains(mydata)).ToList();
               
            if (mydata != null)
            {
                return Json(data);
            }
            else
            {
                return Json(db.products.ToList());
            }
        }

        public IActionResult EditProduct(int pid)
        {
            var data = db.products.Find(pid);
            return Json(data);
        }

        public IActionResult UpdateProduct(Product p)
        {
            db.products.Update(p);
            db.SaveChanges();
            return Json("");
        }
    }
}

 
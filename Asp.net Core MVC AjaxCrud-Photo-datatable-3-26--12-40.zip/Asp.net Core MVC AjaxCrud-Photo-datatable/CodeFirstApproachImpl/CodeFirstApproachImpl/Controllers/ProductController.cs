﻿using CodeFirstApproachImpl.Models;
using CodeFirstApproachImpl.Repository;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstApproachImpl.Controllers
{
    public class ProductController : Controller
    {
        IProduct prod;
        public ProductController(IProduct prod)
        {
            this.prod = prod;
        }

        public IActionResult Index()
        {
            var data = prod.FetchProduct();

            return View(data);
            
        }

        public IActionResult AddProduct()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddProduct(Product p)
        {
            prod.AddProduct(p);
            return RedirectToAction("Index");
        }

        public IActionResult DeleteProduct(int id)
        {

            prod.DeleteProduct(id);
            return RedirectToAction("Index");
        }
        public IActionResult SearchProduct(string str)
        {
          var data =  prod.Searchproduct(str);

            return View("Index",data);
        }

    }

}

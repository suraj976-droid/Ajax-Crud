﻿using CodeFirstApproachImpl.Data;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstApproachImpl.Controllers
{
    public class ManagerController : Controller
    {
        private readonly ApplicationDbContext db;
        public ManagerController(ApplicationDbContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}

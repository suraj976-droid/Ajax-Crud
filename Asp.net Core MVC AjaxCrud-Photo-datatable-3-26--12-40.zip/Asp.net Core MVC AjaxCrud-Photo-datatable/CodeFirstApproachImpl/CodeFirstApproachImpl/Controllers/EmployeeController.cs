﻿using CodeFirstApproachImpl.Data;
using CodeFirstApproachImpl.Models;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstApproachImpl.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment env;
        public EmployeeController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }
        public IActionResult Index()
        {
            var data = db.emps.ToList();

            return View(data);
        }

        public IActionResult AddEmp()
        {
            return View();
        }

        // Normal 
        //[HttpPost]
        //public IActionResult AddEmp(Emp e)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.emps.Add(e);
        //        db.SaveChanges();
        //        TempData["Success"] = "Emp Added Successfully";
        //        return RedirectToAction("Index");
        //    }
        //    else
        //    {
        //        return View();
        //    }
        //}

        // File Upload
        [HttpPost]
        public IActionResult AddEmp(EmpView e)
        {
            if (ModelState.IsValid)
            {
                string path = env.WebRootPath;
                string filepath = "Content/Images/" + e.eimg.FileName;
                string fullpath = Path.Combine(path, filepath);
                UploadFile(e.eimg, fullpath);
                var em = new Emp()
                {
                    ename = e.ename,
                    email = e.email,
                    esalary = e.esalary,
                    eimg = filepath
                };
                db.emps.Add(em);
                db.SaveChanges();
                TempData["Success"] = "Emp Added Successfully";
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public void UploadFile(IFormFile file, string path)
        {
            FileStream stream = new FileStream(path, FileMode.Create);
            file.CopyTo(stream);
        }

        public IActionResult DeleteEmp(int id)
        {
            //var d=db.emps.Where(x=> x.eid==id).SingleOrDefault();
            var data = db.emps.Find(id);
            if (data != null)
            {
                db.emps.Remove(data);
                db.SaveChanges();
                TempData["Delete"] = "Emp Deleted Successfully";
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }
        public IActionResult EditEmp(int id)
        {
            var data = db.emps.Find(id);

            return View(data);
        }

        // Normal
        //[HttpPost]
        //public IActionResult EditEmp(Emp e)
        //{
        //    if (ModelState.IsValid)
        //    {

        //        db.emps.Update(e);
        //        db.SaveChanges();
        //        TempData["Edit"] = "Emp Updated Successfully";
        //        return RedirectToAction("Index");
        //    }
        //    else
        //    {
        //        return View();
        //    }
        //}

        // File Upload In Edit Section
        [HttpPost]
        public IActionResult EditEmp(Emp e, IFormFile eimg)
        {
            Emp em;

            if (eimg == null)
            {

                var img = db.emps.Where(x => x.eid.Equals(e.eid)).Select(x => x.eimg).SingleOrDefault();

                em = new Emp()
                {
                    eid = e.eid,
                    ename = e.ename,
                    email = e.email,
                    esalary = e.esalary,
                    eimg = img
                };

            }
            else
            {
                string path = env.WebRootPath;

                string filePath = "Content/Images/" + eimg.FileName;

                string fullpath = Path.Combine(path, filePath);

                UploadFile(eimg, fullpath);

                em = new Emp()
                {
                    eid = e.eid,
                    ename = e.ename,
                    email = e.email,
                    esalary = e.esalary,
                    eimg = filePath
                };

            }


            db.emps.Update(em);
            db.SaveChanges();

            TempData["Edit"] = "Emp Updated Successfully";
            return RedirectToAction("Index");


        }

    }
}


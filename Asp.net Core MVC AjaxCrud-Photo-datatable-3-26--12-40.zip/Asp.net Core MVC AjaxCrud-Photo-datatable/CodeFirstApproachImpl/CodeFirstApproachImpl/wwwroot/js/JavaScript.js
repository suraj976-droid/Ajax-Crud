﻿
$(document).ready(function () {
    fecthdata();
});

$("#btnmodal").click(function () {
    $("#exampleModal").modal('show');
    $("#submitbtn").show();
    $("#updbtn").hide();
    $("#exampleModalLabel").text("Insert Product");
});

$("#submitbtn").click(function () {

    //var obj = {

    //    pname: $("#Pname").val(),
    //    pcat: $("#Pcat").val(),
    //    price: $("#Price").val(),
    //}

    var obj = $("#myform").serialize();

    $.ajax({
                url: '/Ajax/AddProduct',
                type: 'Post',
                dataType: 'json',
                data: obj,
                contentType: 'Application/x-www-form-urlencoded;charset=utf-8',
                success: function () 
                        {
                    alert("Product Added Successfully");
                    $("#exampleModal").modal('hide');
                    fecthdata();
                        },
                error: function ()
                   {
                    alert("Something Went Wrong");
                    }
        });

});

function fecthdata() {
    $.ajax({
        url: '/Ajax/FetchProduct',
        type: 'Get',
        dataType: 'json',
        contentType: 'Application/json;charset=utf-8',
        success: function (result, sta, xhr) {
            var obj = '';
            $.each(result, function (index, item) {
                obj += '<tr>';
                obj += '<td>' + item.pid + '</td>';
                obj += '<td>' + item.pname + '</td>';
                obj += '<td>' + item.pcat + '</td>';
                obj += '<td>' + item.price + '</td>';
                obj += '<td><a class="btn btn-sm btn-danger" onclick="DeleteProduct(' + item.pid + ')" >Delete</a> </td>';
                obj += '<td><a class="btn btn-sm btn-warning" onclick="EditProduct(' + item.pid + ')" >Edit</a> </td>';
                obj += '</tr>';
            });
                $("#mydata").html(obj);
        },
        error: function () {
            alert("something is wrong")
        }
        
    });
}

function DeleteProduct(id) {
    if (confirm("Are you sure you want to delete this product?")) {
        $.ajax({
            url: '/Ajax/DelProd?pid=' + id,
            success: function () {
                alert("Product Deleted Successfully");
                fecthdata();
            },
            error: function () {
                alert("Something Went Wrong");
            }
        });

    }
    else {
        alert("Thanks");
    }
}


$("#txt").on('input', function () {

    var data = $("#txt").val();
    $.ajax({
        url: '/Ajax/SearchProducts?mydata=' + data,
        type: 'Get',
        dataType: 'json',
        contentType: 'Application/json;charset=utf-8',
        success: function (result, sta, xhr) {
            var obj = '';
            $.each(result, function (index, item) {
                obj += '<tr>';
                obj += '<td>' + item.pid + '</td>';
                obj += '<td>' + item.pname + '</td>';
                obj += '<td>' + item.pcat + '</td>';
                obj += '<td>' + item.price + '</td>';
                obj += '<td><a class="btn btn-sm btn-danger" onclick="DeleteProduct(' + item.pid + ')" >Delete</a> </td>';
                obj += '<td><a class="btn btn-sm btn-warning" onclick="EditProduct(' + item.pid + ')" >Edit</a> </td>';
                obj += '</tr>';
            });
            $("#mydata").html(obj);
        },
        error: function () {
            alert("something is wrong")
        }
    });
});


function EditProduct(id)
{
    $.ajax({
        url: '/ Ajax/EditProduct?pid=' + id,
        type: 'Get',
        dataType: 'json',
        contentType: 'Application/json;charset=utf-8',
        success: function (result, sta, xhr) {
            $("#exampleModal").modal('show');
            $("#pid").val(result.pid);
            $("#Pname").val(result.pname);
            $("#Pcat").val(result.pcat);
            $("#Price").val(result.price);
            $("#submitbtn").hide();
            $("#updbtn").show();
            $("#exampleModalLabel").text("Update Product");

        },
        error: function () {
            alert("something is wrong")
        }
    })

}